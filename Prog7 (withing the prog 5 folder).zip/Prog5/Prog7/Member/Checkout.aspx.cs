﻿using prog4.Prog5.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog4.Prog5.Prog7
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        private List<shoppingBag> bagList
        {
            get
            {
                if (Session["bagList"] == null)
                {
                    Session["bagList"] = new List<shoppingBag>();
                }
                return (List<shoppingBag>)Session["bagList"];
            }
            set { Session["bagList"] = value; }
        }

        private double total
        {
            get
            {
                if (Session["total"] == null)
                {
                    Session["total"] = 0.00;
                }
                return (double)Session["total"];
            }
            set { Session["total"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["bagList"] != null)
            {
                
                //DataTable dataTable = new DataTable();
                //DataColumn dataColumn;
                //dataColumn = new DataColumn("ProdID");
                //dataTable.Columns.Add(dataColumn);
                //dataColumn = new DataColumn("ProdName");
                //dataTable.Columns.Add(dataColumn);
                //dataColumn = new DataColumn("ProdPrice");
                //dataTable.Columns.Add(dataColumn);
                //dataColumn = new DataColumn("ProdQty");
                //dataTable.Columns.Add(dataColumn);
                //dataColumn = new DataColumn("ProdCost");
                //dataTable.Columns.Add(dataColumn);
                for (int i = 0; i < bagList.Count; i++)
                {
                    ShoppingItem item = (ShoppingItem)LoadControl("~/Prog5/Prog7/ShoppingItem.ascx");
                    //theForm.Controls.Add(item);
                    item.setID = bagList[i].getProdID();
                    item.setName = bagList[i].getProdName();
                    item.setPrice = bagList[i].getProdPrice();
                    item.setQty = bagList[i].getProdQty();
                    item.setCost = bagList[i].getProdSubtotal();
                    total += item.setCost;
                    Panel1.Controls.Add(item);
                }
                txtTotal.Text = string.Format("$ {0:#,##0.00}", total.ToString());
            }
        }

        protected void btnCheckout_Click(object sender, EventArgs e)
        {
            Session["bagList"] = null;
            Response.Redirect("~/prog5/login.aspx");
        }
    }
}