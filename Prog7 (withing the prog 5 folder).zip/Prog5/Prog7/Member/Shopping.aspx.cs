﻿using prog4.Prog5.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog4.Prog5.Prog7
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        private const double tax = 0.055;
        private const int COL_1 = 0;
        private const int COL_2 = 1;
        private const int COL_3 = 2;
        private const int COL_4 = 3;


        private double price
        {
            get
            {
                if (Session["price"] == null)
                {
                    Session["price"] = 0;
                }
                return (double)Session["price"];
            }
            set { Session["price"] = value; }
        }
        private double subtotal
        {
            get
            {
                if (Session["subtotal"] == null)
                {
                    Session["subtotal"] = 0;
                }
                return (double)Session["subtotal"];
            }
            set { Session["subtotal"] = value; }
        }

        private double grandTotal
        {
            get
            {
                if (Session["grandTotal"] != null)
                {
                    return (double)Session["grandTotal"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["grandTotal"] = value; }
        }

        private double taxTotal
        {
            get
            {
                if (Session["taxTotal"] != null)
                {
                    return (double)Session["taxTotal"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["taxTotal"] = value; }
        }

        private List<shoppingBag> bagList
        {
            get
            {
                if (Session["bagList"] == null)
                {
                    Session["bagList"] = new List<shoppingBag>();
                }
                return (List<shoppingBag>)Session["bagList"];
            }
            set { Session["bagList"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void btnCompute_Click(object sender, EventArgs e)
        {
            try
            {
                if (btnCompute.Text == "Compute")
                {
                    DataSourceSelectArguments args = new DataSourceSelectArguments();
                    DataView view = (DataView)SqlDataSource1.Select(args);
                    DataTable dt = view.ToTable();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (dt.Rows[i][COL_1].ToString() == txtID.Text)
                        {
                            txtPrice.Text = dt.Rows[i][COL_3].ToString();
                            txtName.Text = dt.Rows[i][COL_2].ToString();
                        }
                    }
                    txtID.ReadOnly = true;
                    txtName.ReadOnly = true;
                    txtQuantity.ReadOnly = true;
                    price = double.Parse(txtPrice.Text);
                    subtotal = price * double.Parse(txtQuantity.Text);
                    txtSubTotal.Text = subtotal.ToString();
                    taxTotal = subtotal * tax;
                    txtTax.Text = taxTotal.ToString();
                    grandTotal = subtotal + taxTotal;
                    txtGrandTotal.Text = grandTotal.ToString();
                    txtPrice.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtPrice.Text));
                    txtSubTotal.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtSubTotal.Text));
                    txtTax.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtTax.Text));
                    txtGrandTotal.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtGrandTotal.Text));
                    btnAddBag.Enabled = true;
                    btnAddBag.Focus();
                    btnCompute.Text = "Clear";
                }
                else if (btnCompute.Text == "Clear")
                {
                    txtID.ReadOnly = false;
                    txtName.ReadOnly = false;
                    txtQuantity.ReadOnly = false;
                    txtID.Text = "";
                    txtName.Text = "";
                    txtPrice.Text = "";
                    txtQuantity.Text = "";
                    txtSubTotal.Text = "";
                    txtTax.Text = "";
                    txtGrandTotal.Text = "";
                    txtID.Focus();
                    btnCompute.Text = "Compute";
                }
            }
            catch (Exception ex)
            {
                Response.Write("Error: " + ex.Message);
            }
        }

        protected void btnAddBag_Click(object sender, EventArgs e)
        {
            btnAddBag.Enabled = false;
            shoppingBag newItem = new shoppingBag(txtID.Text, txtName.Text, price, int.Parse(txtQuantity.Text), subtotal);
            bagList.Add(newItem);
        }

        public List<shoppingBag> getbagList()
        {
            return bagList;
        }
    }
}