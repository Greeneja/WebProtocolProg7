﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog4.Prog5.Prog7
{
    public partial class ShoppingItem : System.Web.UI.UserControl
    {
        //private string theID
        //{
        //    get
        //    {
        //        if (Session["theID"] == null)
        //        {
        //            Session["theID"] = "";
        //        }
        //        return (string)Session["theID"];
        //    }
        //    set { Session["theID"] = value; }
        //}

        //private string theName
        //{
        //    get
        //    {
        //        if (Session["theName"] == null)
        //        {
        //            Session["theName"] = "";
        //        }
        //        return (string)Session["theName"];
        //    }
        //    set { Session["theName"] = value; }
        //}

        //private double thePrice
        //{
        //    get
        //    {
        //        if (Session["thePrice"] == null)
        //        {
        //            Session["thePrice"] = 0.00;
        //        }
        //        return (double)Session["thePrice"];
        //    }
        //    set { Session["thePrice"] = value; }
        //}

        //private int theQuantity
        //{
        //    get
        //    {
        //        if (Session["theQuantity"] == null)
        //        {
        //            Session["theQuantity"] = 0;
        //        }
        //        return (int)Session["theQuantity"];
        //    }
        //    set { Session["theQuantity"] = value; }
        //}

        //private double theCost
        //{
        //    get
        //    {
        //        if (Session["theCost"] == null)
        //        {
        //            Session["theCost"] = 0.00;
        //        }
        //        return (double)Session["theCost"];
        //    }
        //    set { Session["theCost"] = value; }
        //}

        private string theID, theName;
        private double thePrice, theCost;
        private int theQuantity;


        public event ItemChangedHandler ItemChanged;

        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            txtID.Text = theID;
            txtName.Text = theName;
            txtPrice.Text = string.Format("$ {0:#,##0.00}", thePrice.ToString());
            txtQuantity.Text = theQuantity.ToString();
            txtCost.Text = string.Format("$ {0:#,##0.00}", theCost.ToString());
        }

        public delegate void ItemChangedHandler(object x, bool valid);

        public string setID
        {
            set
            {
                theID = value.ToString();
            }
            get
            {
                return theID;
            }
        }


        public string setName
        {
            set
            {
                theName = value.ToString();
            }
            get
            {
                return theName;
            }
        }

        public double setPrice
        {
            set
            {
                thePrice = value;
            }
            get
            {
                return thePrice;
            }
        }

        public int setQty
        {
            set
            {
                theQuantity = value;
            }
            get
            {
                return theQuantity;
            }
        }

        public double setCost
        {
            set
            {
                theCost = value;
            }
            get
            {
                return theCost;
            }
        }

    }
}