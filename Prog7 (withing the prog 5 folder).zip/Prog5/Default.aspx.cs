﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog4.Prog4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //App_Code.SQLDataClass.getAllProducts();
            //ProductGrid.DataSource = App_Code.SQLDataClass.tblProduct;
            //ProductGrid.DataBind();
        }

        protected void ProductGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ProductGrid.PageIndex = e.NewPageIndex;
            ProductGrid.DataBind();
        }
    }
}